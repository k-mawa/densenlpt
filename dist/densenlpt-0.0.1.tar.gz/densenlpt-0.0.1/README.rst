`audiblerangepy` is a package for checking some frequency is audible or not for some human-being and animals

Requirements
------------
* Python 3.x
(you may work by Python2.x)
Features
--------
* nothing

History
-------
0.0.1 (2017-7-20)
~~~~~~~~~~~~~~~~~~
* first release

Usage
------------
please look at Github README
~~~~~~~~~~~~~~~~~~

Plan to upgrade
-------
*add some more maltiple method when you create dictionary
*add some more maltiple method when you create corpus, vector
*add some method when you plot some results of analysis
and more, if i can
~~~~~~~~~~~~~~~~~~
* first release