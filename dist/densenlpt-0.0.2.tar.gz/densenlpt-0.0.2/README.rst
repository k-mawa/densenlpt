`densenlpt` is a python package for creating dictionary and vector from scentences & training model to predict.  mainly it is used for Japanese Language Analysis

Requirements
------------
* Python 3.x
(you may work by Python2.x)
Features
--------
* nothing

History
-------
0.0.1 (2017-7-20)
0.0.2 (2017-7-29)
~~~~~~~~~~~~~~~~~~
* first release

Usage
------------
please look at Github README
~~~~~~~~~~~~~~~~~~

Plan to upgrade
-------
*add some more maltiple method when you create dictionary
*add some more maltiple method when you create corpus, vector
*add some method when you plot some results of analysis
and more, if i can
~~~~~~~~~~~~~~~~~~
* first release